package com.pcs.apptoko.response.login

data class Admin(
    val email: String,
    val id: String,
    val nama: String,
    val password: String
)