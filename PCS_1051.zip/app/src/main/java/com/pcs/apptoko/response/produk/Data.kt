package com.pcs.apptoko.response.produk

data class Data(
    val produk: List<Produk>
)